Runtime dumper compact output
=============================
chunks.txt       captured source chunks
http.txt         captured HTTP data
functions.txt    function metadata and closure records
decompiled.txt   bounded source-like decompiles
values.txt       constants, upvalues and runtime values
tables.txt       bounded getgc table snapshots
bytecode.txt     bytecode lengths and hashes
connections.txt  captured connection metadata
trace.txt        bounded call/return/line trace
trace_source.txt source-shaped trace with synthetic names
events.txt       capture events
features.txt     feature-detection report
summary.txt      capture counts

All compact files are plain text and are split at a bounded size.
Names/upvalues marked synthetic, inferred or unresolved are not
claims about the original obfuscated source.