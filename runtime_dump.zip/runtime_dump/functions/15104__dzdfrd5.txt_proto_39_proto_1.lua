-- runtime-dumper decompile; source names are executor-provided when available
-- function: _dzdfrd5.txt_proto_39_proto_1
-- upvalues: INFERRED/UNRESOLVED unless an executor artifact proves otherwise

-- Decompiled with Potassium's decompiler.

local v1, v2;
local _ = v1 * v2;
