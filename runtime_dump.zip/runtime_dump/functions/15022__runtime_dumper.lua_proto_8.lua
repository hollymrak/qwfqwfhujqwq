-- runtime-dumper decompile; source names are executor-provided when available
-- function: _runtime_dumper.lua_proto_8
-- upvalues: INFERRED/UNRESOLVED unless an executor artifact proves otherwise

-- Decompiled with Potassium's decompiler.

local v1;
local _ = v1 * UNNAMED_2338679619688;
