-- runtime-dumper decompile; source names are executor-provided when available
-- function: _runtime_dumper.lua_proto_17
-- upvalues: INFERRED/UNRESOLVED unless an executor artifact proves otherwise

-- Decompiled with Potassium's decompiler.

local _ = UNNAMED_2338679624584 * UNNAMED_2338679632600;
