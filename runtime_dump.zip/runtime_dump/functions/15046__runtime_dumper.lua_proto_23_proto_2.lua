-- runtime-dumper decompile; source names are executor-provided when available
-- function: _runtime_dumper.lua_proto_23_proto_2
-- upvalues: INFERRED/UNRESOLVED unless an executor artifact proves otherwise

-- Decompiled with Potassium's decompiler.

local _ = UNNAMED_2338679621224 * UNNAMED_2338679624968;
