-- runtime-dumper decompile; source names are executor-provided when available
-- function: _dzdfrd5.txt_proto_57
-- upvalues: INFERRED/UNRESOLVED unless an executor artifact proves otherwise

-- Decompiled with Potassium's decompiler.

local v1;
local _ = v1 * UNNAMED_2338679634472;
