-- runtime-dumper decompile; source names are executor-provided when available
-- function: _dzdfrd5.txt_proto_67
-- upvalues: INFERRED/UNRESOLVED unless an executor artifact proves otherwise

-- Decompiled with Potassium's decompiler.

local _ = UNNAMED_2338679634808 * UNNAMED_2338679626312;
