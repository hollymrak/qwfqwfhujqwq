-- runtime-dumper decompile; source names are executor-provided when available
-- function: _runtime_dumper.lua_proto_19
-- upvalues: INFERRED/UNRESOLVED unless an executor artifact proves otherwise

-- Decompiled with Potassium's decompiler.

local _ = UNNAMED_2338679629192 * UNNAMED_2338679632648;
