-- runtime-dumper decompile; source names are executor-provided when available
-- function: _dzdfrd5.txt_proto_12
-- upvalues: INFERRED/UNRESOLVED unless an executor artifact proves otherwise

-- Decompiled with Potassium's decompiler.

local _ = UNNAMED_2338679623672 * UNNAMED_2338679619592;
