-- runtime-dumper decompile; source names are executor-provided when available
-- function: _dzdfrd5.txt_proto_38
-- upvalues: INFERRED/UNRESOLVED unless an executor artifact proves otherwise

-- Decompiled with Potassium's decompiler.

local _ = UNNAMED_2338679621272 * UNNAMED_2338679624872;
