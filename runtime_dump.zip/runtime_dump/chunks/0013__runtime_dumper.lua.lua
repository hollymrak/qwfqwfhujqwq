--[=[
    Runtime Dumper / Trace Collector for authorized Luau debugging
    ----------------------------------------------------------------
    This is an instrumentation dumper, not a magic Luraph decompiler. It
    captures source strings passed to load/loadstring, optional HTTP payloads,
    executor decompiler output (when the executor exposes decompile), function
    metadata from debug/getgc, and a bounded call trace. Every capture is
    written with writefile under the configured directory.

    Use:
      local Dumper = loadstring(readfile("runtime_dumper.lua"))()
      Dumper:install()
      Dumper:run(readfile("dzdfrd5.txt"), "@dzdfrd5.txt")
      Dumper:scan_gc()
      Dumper:flush()

    The dumper deliberately does not patch every Roblox method: doing that is
    unstable and changes the behavior being measured. The hooks are narrowly
    scoped to loaders, HTTP request entry points, optional debug hooks, and
    optional function enumeration.
]=]

local unpack_ = table.unpack or unpack
local genv = (type(getgenv) == "function" and getgenv()) or _G
local Dumper = {}
Dumper.__index = Dumper
Dumper.VERSION = "runtime-dumper-1.0"

local function bool(v)
    return v == true
end

local function safe_call(fn, ...)
    if type(fn) ~= "function" then
        return false, "not a function"
    end
    return pcall(fn, ...)
end

local function sanitize_name(value)
    value = tostring(value or "chunk")
    value = value:gsub("[^%w%._%-]+", "_")
    value = value:gsub("_+", "_")
    if #value > 96 then
        value = value:sub(1, 96)
    end
    if value == "" then
        value = "chunk"
    end
    return value
end

local function hash_text(text)
    -- FNV-1a with a bit32 fallback. It is only a filename/deduplication key,
    -- not a cryptographic signature.
    local bxor = bit32 and bit32.bxor
    local band = bit32 and bit32.band
    local h = 2166136261
    for i = 1, #text do
        local b = string.byte(text, i)
        if bxor and band then
            h = band(bxor(h, b) * 16777619, 0xFFFFFFFF)
        else
            h = (h * 33 + b) % 4294967296
        end
    end
    return string.format("%08x", h)
end

local function line_count(text)
    if type(text) ~= "string" or text == "" then
        return 0
    end
    local _, n = text:gsub("\n", "\n")
    return n + 1
end

function Dumper.new(options)
    options = options or {}
    local self = setmetatable({}, Dumper)
    self.root = options.root or "runtime_dump"
    self.compact = options.compact == true
    self.compact_part_bytes = options.compact_part_bytes or (8 * 1024 * 1024)
    self.compact_flush_bytes = options.compact_flush_bytes or (64 * 1024)
    self.max_compact_parts = options.max_compact_parts or 16
    self.compact_states = {}
    self.trace_written = 0
    self.runtime_values_written = 0
    self.trace_source_started = false
    self.trace_source_closed = false
    self.max_trace_events = options.max_trace_events or 250000
    self.max_gc_functions = options.max_gc_functions or 10000
    self.max_gc_tables = options.max_gc_tables or 2000
    self.max_decompiled_functions = options.max_decompiled_functions or 250
    self.max_deep_captures = options.max_deep_captures or 1000
    self.max_runtime_values = options.max_runtime_values or 100000
    self.trace_flush_every = options.trace_flush_every or 2048
    self.flush_every = options.flush_every or 256
    self.hook_http = options.hook_http ~= false
    self.hook_instance_new = options.hook_instance_new == true
    self.enable_debug_hook = options.enable_debug_hook ~= false
    self.scan_decompile = options.scan_decompile ~= false
    self.env = options.env or genv
    self.installed = false
    self.hook_depth = 0
    self.trace_depth = 0
    self.debug_hook_active = false
    self.event_id = 0
    self.capture_id = 0
    self.trace = {}
    self.events = {}
    self.seen_text = {}
    self.text_count = 0
    self.seen_functions = {}
    self.function_count = 0
    self.table_count = 0
    self.decompiled_count = 0
    self.deep_capture_count = 0
    self.runtime_values = {}
    self.originals = {}
    self.hooked = {}
    self.hooked_targets = {}
    self.started_at = os.clock()
    return self
end

function Dumper:_mkdir(path)
    if type(makefolder) ~= "function" then
        return
    end
    local current = ""
    for part in tostring(path):gmatch("[^/]+") do
        current = current == "" and part or (current .. "/" .. part)
        local exists = false
        if type(isfolder) == "function" then
            local ok, result = pcall(isfolder, current)
            exists = ok and result == true
        end
        if not exists then
            pcall(makefolder, current)
        end
    end
end

function Dumper:_ensure_root()
    self:_mkdir(self.root)
    if self.compact then
        return
    end
    self:_mkdir(self.root .. "/chunks")
    self:_mkdir(self.root .. "/http")
    self:_mkdir(self.root .. "/functions")
    self:_mkdir(self.root .. "/bytecode")
    self:_mkdir(self.root .. "/snapshots")
end

function Dumper:_compact_path(kind, part)
    local suffix = part > 1 and string.format("_%03d", part) or ""
    return self.root .. "/" .. sanitize_name(kind) .. suffix .. ".txt"
end

function Dumper:_compact_flush(kind)
    local state = self.compact_states[kind]
    if not state or state.buffer_bytes == 0 then
        return
    end
    local data = table.concat(state.buffer)
    self:_write(self:_compact_path(kind, state.part), data, true)
    state.buffer = {}
    state.buffer_bytes = 0
end

function Dumper:_compact_append(kind, text)
    if not self.compact or type(text) ~= "string" or #text == 0 then
        return
    end
    local state = self.compact_states[kind]
    if not state then
        state = {
            part = 1,
            bytes = 0,
            buffer = {},
            buffer_bytes = 0,
            records = 0,
            initialized = false,
            dropped = false,
        }
        self.compact_states[kind] = state
    end
    if state.dropped then
        return
    end
    if not state.initialized then
        local header = string.format(
            "\n===== runtime-dumper %s; synthetic/inferred data is marked =====\n",
            tostring(kind)
        )
        text = header .. text
        state.initialized = true
    end
    if state.bytes + state.buffer_bytes + #text > self.compact_part_bytes and state.bytes > 0 then
        self:_compact_flush(kind)
        state.part = state.part + 1
        state.bytes = 0
        state.initialized = false
        if state.part > self.max_compact_parts then
            state.dropped = true
            self:_log("compact output limit reached for " .. tostring(kind))
            return
        end
        return self:_compact_append(kind, text)
    end
    state.buffer[#state.buffer + 1] = text
    state.buffer_bytes = state.buffer_bytes + #text
    state.bytes = state.bytes + #text
    state.records = state.records + 1
    if state.buffer_bytes >= self.compact_flush_bytes then
        self:_compact_flush(kind)
    end
end

function Dumper:_compact_flush_all()
    if not self.compact then
        return
    end
    for kind in pairs(self.compact_states) do
        self:_compact_flush(kind)
    end
end

function Dumper:_write(path, data, append)
    if type(writefile) ~= "function" then
        return false, "writefile is unavailable"
    end
    self:_mkdir(path:match("^(.*)/[^/]+$") or self.root)

    local function write_once(destination, payload)
        local ok, result = pcall(writefile, destination, payload)
        if ok and result ~= false then
            return true, result
        end
        return false, result
    end

    local payload = data
    if append then
        if type(appendfile) == "function" then
            local ok, result = pcall(appendfile, path, data)
            if ok and result ~= false then
                return true, result
            end
        end
        local previous = ""
        if type(readfile) == "function" then
            local read_ok, existing = pcall(readfile, path)
            if read_ok and type(existing) == "string" then
                previous = existing
            end
        end
        payload = previous .. data
    end

    local ok, result = write_once(path, payload)
    if ok then
        return ok, result
    end
    -- A few environments expose writefile but do not allow creating nested
    -- directories. Preserve the capture in a flat fallback filename.
    local flat = path:gsub("[/\\\\]", "__")
    if flat ~= path then
        return write_once(flat, payload)
    end
    return ok, result
end

function Dumper:_log(message)
    local line = string.format("[%06d] %s", self.event_id + 1, tostring(message))
    self.event_id = self.event_id + 1
    self.events[#self.events + 1] = line
    if #self.events >= self.flush_every then
        local data = table.concat(self.events, "\n") .. "\n"
        if self.compact then
            self:_compact_append("events", data)
        else
            self:_write(self.root .. "/events.log", data, true)
        end
        self.events = {}
    end
end

function Dumper:_repr(value, depth, seen)
    depth = depth or 0
    seen = seen or {}
    local kind = type(value)
    if kind == "nil" then
        return "nil"
    elseif kind == "string" then
        return string.format("%q", value)
    elseif kind == "number" or kind == "boolean" then
        return tostring(value)
    elseif kind == "function" then
        local info = self:_function_info(value)
        return "<function " .. (info.short or "?") .. ">"
    elseif kind == "thread" or kind == "userdata" then
        local ok, full_name = pcall(function()
            if value.GetFullName then
                return value:GetFullName()
            end
            return tostring(value)
        end)
        return ok and ("<" .. tostring(full_name) .. ">") or ("<" .. kind .. ">")
    elseif kind ~= "table" then
        return "<" .. kind .. ">"
    end
    if seen[value] then
        return "<cycle>"
    end
    if depth >= 3 then
        return "{...}"
    end
    seen[value] = true
    local parts = {}
    local count = 0
    for key, item in pairs(value) do
        count = count + 1
        if count > 80 then
            parts[#parts + 1] = "..."
            break
        end
        parts[#parts + 1] = "[" .. self:_repr(key, depth + 1, seen) .. "]=" .. self:_repr(item, depth + 1, seen)
    end
    seen[value] = nil
    return "{" .. table.concat(parts, ", ") .. "}"
end

function Dumper:_capture_runtime_value(label, value)
    if #self.runtime_values >= self.max_runtime_values then
        return
    end
    local ok, rendered = pcall(function()
        return self:_repr(value)
    end)
    if not ok then
        rendered = "<unprintable: " .. tostring(rendered) .. ">"
    end
    self.runtime_values[#self.runtime_values + 1] = string.format(
        "%06d  %s = %s",
        #self.runtime_values + 1,
        tostring(label),
        rendered
    )
end

function Dumper:_function_info(fn)
    local info = { short = "anonymous", type = type(fn) }
    if type(debug) == "table" and type(debug.getinfo) == "function" then
        local ok, result = pcall(debug.getinfo, fn)
        if ok and type(result) == "table" then
            info.source = result.source or result.short_src
            info.short_src = result.short_src
            info.name = result.name
            info.what = result.what
            info.linedefined = result.linedefined
            info.lastlinedefined = result.lastlinedefined
            info.currentline = result.currentline
            info.nups = result.nups
            info.short = result.name or result.short_src or result.source or "anonymous"
        end
    end
    return info
end

function Dumper:_capture_text(kind, text, name, extension)
    if type(text) ~= "string" then
        return nil
    end
    local digest = hash_text(text)
    if self.seen_text[digest] then
        self:_log("duplicate " .. kind .. " " .. digest .. " skipped")
        return digest
    end
    self.seen_text[digest] = true
    self.text_count = self.text_count + 1
    self.capture_id = self.capture_id + 1
    if self.compact then
        local block = string.format(
            "\n--- capture %04d | name=%s | hash=%s | bytes=%d | lines=%d ---\n%s\n",
            self.capture_id,
            sanitize_name(name),
            digest,
            #text,
            line_count(text),
            text
        )
        self:_compact_append(kind, block)
        self:_log(string.format("captured %s in compact output (%d bytes)", kind, #text))
        return digest
    end
    extension = extension or "lua"
    local file = string.format("%s/%s/%04d_%s.%s", self.root, kind, self.capture_id, sanitize_name(name), extension)
    self:_write(file, text, false)
    self:_log(string.format("captured %s: %s (%d bytes, %d lines)", kind, file, #text, line_count(text)))
    return digest
end

function Dumper:_capture_function(fn, label)
    if type(fn) ~= "function" then
        return
    end
    local info = self:_function_info(fn)
    local identity = tostring(fn) .. "|" .. tostring(info.source) .. "|" .. tostring(info.linedefined)
    if self.seen_functions[identity] then
        return
    end
    self.seen_functions[identity] = true
    self.function_count = self.function_count + 1
    local safe_label = sanitize_name(label or info.short or "function")
    local serial = self.function_count
    local base = string.format("%s/functions/%05d_%s", self.root, serial, safe_label)
    local info_block = string.format(
        "\n===== FUNCTION %05d | %s =====\nlabel=%s\nmetadata=%s\n",
        serial,
        safe_label,
        safe_label,
        self:_repr(info)
    )
    if self.compact then
        self:_compact_append("functions", info_block)
    else
        self:_write(base .. ".info.txt", self:_repr(info) .. "\n", false)
    end

    -- Deep executor introspection can be very expensive on a large getgc
    -- result. Metadata is still collected for every function, while the
    -- expensive part is explicitly bounded.
    local do_deep_capture = self.deep_capture_count < self.max_deep_captures
    if do_deep_capture then
        self.deep_capture_count = self.deep_capture_count + 1
    end

    -- Some executors expose a real decompiler. Use it when present; unlike
    -- debug.getinfo, this can return source-like text for a VM-generated fn.
    if self.scan_decompile
        and type(decompile) == "function"
        and self.decompiled_count < self.max_decompiled_functions then
        self.decompiled_count = self.decompiled_count + 1
        local ok, source = pcall(decompile, fn)
        if ok and type(source) == "string" and #source > 0 then
            local rendered = table.concat({
                "-- runtime-dumper decompile; source names are executor-provided when available",
                "-- function: " .. safe_label,
                "-- upvalues: INFERRED/UNRESOLVED unless an executor artifact proves otherwise",
                "",
                source,
                "",
            }, "\n")
            if self.compact then
                self:_compact_append(
                    "decompiled",
                    string.format(
                        "\n===== DECOMPILED FUNCTION %05d | %s =====\n%s\n",
                        serial,
                        safe_label,
                        rendered
                    )
                )
                self:_log("decompiled function appended to compact output")
            else
                self:_write(base .. ".lua", rendered, false)
                self:_log("decompiled function: " .. base .. ".lua")
            end
        end
    end

    if not do_deep_capture then
        return
    end

    -- Optional executor introspection. It is bounded and written as text so
    -- a failed/unsupported API cannot stop the target script.
    if type(getconstants) == "function" then
        local ok, constants = pcall(getconstants, fn)
        if ok then
            local rendered = string.format(
                "\n--- CONSTANTS %05d | %s ---\n%s\n",
                serial,
                safe_label,
                self:_repr(constants)
            )
            if self.compact then
                self:_compact_append("values", rendered)
            else
                self:_write(base .. ".constants.txt", self:_repr(constants) .. "\n", false)
            end
        end
    end
    if type(getupvalues) == "function" then
        local ok, upvalues = pcall(getupvalues, fn)
        if ok then
            local rendered = string.format(
                "\n--- UPVALUES %05d | %s ---\n%s\n",
                serial,
                safe_label,
                self:_repr(upvalues)
            )
            if self.compact then
                self:_compact_append("values", rendered)
            else
                self:_write(base .. ".upvalues.txt", self:_repr(upvalues) .. "\n", false)
            end
        end
    elseif type(debug) == "table" and type(debug.getupvalue) == "function" then
        local upvalues = {}
        for index = 1, 64 do
            local value_ok, name, value = pcall(debug.getupvalue, fn, index)
            if not value_ok or name == nil then
                break
            end
            upvalues[name] = value
        end
        local rendered = string.format(
            "\n--- UPVALUES %05d | %s ---\n%s\n",
            serial,
            safe_label,
            self:_repr(upvalues)
        )
        if self.compact then
            self:_compact_append("values", rendered)
        else
            self:_write(base .. ".upvalues.txt", self:_repr(upvalues) .. "\n", false)
        end
    end
    if type(getprotos) == "function" then
        local ok, protos = pcall(getprotos, fn)
        if ok and type(protos) == "table" then
            for index, proto in pairs(protos) do
                if type(proto) == "function" then
                    self:_capture_function(proto, safe_label .. "_proto_" .. tostring(index))
                end
            end
        end
    elseif type(getproto) == "function" then
        for index = 1, 128 do
            local proto_ok, proto = pcall(getproto, fn, index)
            if not proto_ok or type(proto) ~= "function" then
                break
            end
            self:_capture_function(proto, safe_label .. "_proto_" .. tostring(index))
        end
    end
    if type(string.dump) == "function" then
        local ok, bytecode = pcall(string.dump, fn)
        if ok and type(bytecode) == "string" and #bytecode > 0 then
            if self.compact then
                self:_compact_append(
                    "bytecode",
                    string.format(
                        "\n--- BYTECODE %05d | %s | bytes=%d | hash=%s ---\n",
                        serial,
                        safe_label,
                        #bytecode,
                        hash_text(bytecode)
                    )
                )
            else
                self:_write(base .. ".luac", bytecode, false)
            end
        end
    end
end

function Dumper:_capture_loader(kind, source, chunk_name)
    if type(source) == "string" then
        self:_capture_text("chunks", source, chunk_name or kind, "lua")
    end
end

function Dumper:_wrap_global(name)
    local target = self.env and self.env[name]
    if type(target) ~= "function" or self.hooked[name] then
        return false
    end
    if type(hookfunction) == "function" and self.hooked_targets[target] then
        self.originals[name] = self.hooked_targets[target]
        self.hooked[name] = true
        self:_log("reused hook for global " .. name)
        return true
    end
    local state = { original = target }
    local function wrapper(...)
        local args = { ... }
        if self.hook_depth == 0 and (name == "loadstring" or name == "load") and type(args[1]) == "string" then
            self:_capture_loader(name, args[1], args[2])
        end
        self.hook_depth = self.hook_depth + 1
        local packed = { pcall(state.original, unpack_(args)) }
        self.hook_depth = self.hook_depth - 1
        local ok = table.remove(packed, 1)
        if not ok then
            error(packed[1], 0)
        end
        local result = packed[1]
        if type(result) == "function" then
            self:_capture_function(result, args[2] or name)
        end
        return unpack_(packed)
    end
    local wrapped = (type(newcclosure) == "function" and newcclosure(wrapper)) or wrapper
    if type(hookfunction) == "function" then
        local ok, original = pcall(hookfunction, target, wrapped)
        if ok then
            state.original = original or target
            self.originals[name] = state.original
            self.hooked_targets[target] = state.original
            self.hooked[name] = true
            self:_log("hooked global " .. name)
            return true
        end
    end
    -- Fallback for environments without hookfunction. This only affects code
    -- that resolves the global after installation.
    local assigned = pcall(function()
        self.env[name] = wrapped
    end)
    if not assigned then
        self:_log("could not wrap global " .. name)
        return false
    end
    self.originals[name] = target
    self.hooked_targets[target] = target
    self.hooked[name] = true
    self:_log("wrapped global " .. name)
    return true
end

function Dumper:_wrap_request_table(container, key)
    if type(container) ~= "table" or type(container[key]) ~= "function" then
        return false
    end
    local target = container[key]
    if self.hooked[container] and self.hooked[container][key] then
        return false
    end
    self.hooked[container] = self.hooked[container] or {}
    local state = { original = target }
    local function wrapper(request_data, ...)
        if type(request_data) == "table" then
            self:_capture_text("http", self:_repr(request_data), key .. "_request", "txt")
            local body = request_data.Body or request_data.body
            if type(body) == "string" then
                self:_capture_text("http", body, key .. "_body", "txt")
            end
        end
        local packed = { pcall(state.original, request_data, ...) }
        local ok = table.remove(packed, 1)
        if not ok then
            error(packed[1], 0)
        end
        local response = packed[1]
        if type(response) == "table" then
            local body = response.Body or response.body
            if type(body) == "string" then
                self:_capture_text("http", body, key .. "_response", "txt")
            end
        end
        return unpack_(packed)
    end
    local wrapped = (type(newcclosure) == "function" and newcclosure(wrapper)) or wrapper
    if type(hookfunction) == "function" then
        local ok, original = pcall(hookfunction, target, wrapped)
        if ok then
            state.original = original or target
            self:_log("hooked request " .. key)
            return true
        end
    end
    local assigned = pcall(function()
        container[key] = wrapped
    end)
    self:_log(assigned and ("wrapped request " .. key) or ("could not wrap request " .. key))
    return assigned
end

function Dumper:_install_http_hooks()
    if not self.hook_http then
        return
    end
    for _, name in ipairs({ "request", "http_request", "syn_request" }) do
        self:_wrap_global(name)
    end
    if type(syn) == "table" then
        self:_wrap_request_table(syn, "request")
    end
    if type(game) == "userdata" or type(game) == "table" then
        for _, method in ipairs({ "HttpGet", "HttpGetAsync" }) do
            local target_ok, target = pcall(function()
                return game[method]
            end)
            if target_ok and type(target) == "function" and not self.hooked["game." .. method] then
                local state = { original = target }
                local function wrapper(instance, url, ...)
                    if type(url) == "string" then
                        self:_capture_text("http", "URL: " .. url .. "\n", method, "txt")
                    end
                    local packed = { pcall(state.original, instance, url, ...) }
                    local ok = table.remove(packed, 1)
                    if not ok then error(packed[1], 0) end
                    if type(packed[1]) == "string" then
                        self:_capture_text("http", packed[1], method .. "_response", "txt")
                    end
                    return unpack_(packed)
                end
                local wrapped = (type(newcclosure) == "function" and newcclosure(wrapper)) or wrapper
                local installed = false
                if type(hookfunction) == "function" then
                    local ok, original = pcall(hookfunction, target, wrapped)
                    if ok then
                        state.original = original or target
                        installed = true
                    end
                else
                    installed = pcall(function() game[method] = wrapped end)
                end
                self.hooked["game." .. method] = installed
                self:_log(installed and ("hooked game." .. method) or ("could not hook game." .. method))
            end
        end
    end
end

function Dumper:_install_instance_hook()
    if not self.hook_instance_new then
        return
    end
    if (type(Instance) ~= "table" and type(Instance) ~= "userdata") or type(Instance.new) ~= "function" then
        self:_log("Instance.new unavailable")
        return
    end
    local target = Instance.new
    if self.hooked["Instance.new"] then
        return
    end
    local state = { original = target }
    local function wrapper(...)
        local args = { ... }
        local packed = { pcall(state.original, unpack_(args)) }
        local ok = table.remove(packed, 1)
        if not ok then
            error(packed[1], 0)
        end
        local object = packed[1]
        self:_log("Instance.new " .. tostring(args[1]) .. " -> " .. self:_repr(object))
        return unpack_(packed)
    end
    local wrapped = (type(newcclosure) == "function" and newcclosure(wrapper)) or wrapper
    if type(hookfunction) == "function" then
        local ok, original = pcall(hookfunction, target, wrapped)
        if ok then
            state.original = original or target
            self.hooked["Instance.new"] = true
            self:_log("hooked Instance.new")
            return
        end
    end
    local assigned = pcall(function()
        Instance.new = wrapped
    end)
    self.hooked["Instance.new"] = assigned
    self:_log(assigned and "wrapped Instance.new" or "could not wrap Instance.new")
end

function Dumper:_compact_flush_runtime(final)
    if not self.compact then
        return
    end
    if #self.events > 0 then
        self:_compact_append("events", table.concat(self.events, "\n") .. "\n")
        self.events = {}
    end
    if #self.runtime_values > self.runtime_values_written then
        local start = self.runtime_values_written + 1
        self:_compact_append("values", table.concat(self.runtime_values, "\n", start, #self.runtime_values) .. "\n")
        self.runtime_values_written = #self.runtime_values
    end
    if #self.trace > self.trace_written then
        local start = self.trace_written + 1
        self:_compact_append("trace", table.concat(self.trace, "\n", start, #self.trace) .. "\n")
        if not self.trace_source_started then
            self:_compact_append("trace_source", table.concat({
                "local function runtime_trace_0000(...)",
                "    -- upvalues: INFERRED/UNRESOLVED",
            }, "\n") .. "\n")
            self.trace_source_started = true
        end
        local source_listing = {}
        for index = start, #self.trace do
            source_listing[#source_listing + 1] = string.format(
                "    -- line %06d | %s",
                index,
                self.trace[index]
            )
        end
        self:_compact_append("trace_source", table.concat(source_listing, "\n") .. "\n")
        self.trace_written = #self.trace
    end
    if final and self.trace_source_started and not self.trace_source_closed then
        self:_compact_append("trace_source", "end\n")
        self.trace_source_closed = true
    end
    self:_compact_flush_all()
end

function Dumper:_install_debug_hook()
    if not self.enable_debug_hook or type(debug) ~= "table" or type(debug.sethook) ~= "function" then
        self:_log("debug.sethook unavailable")
        return
    end
    local function hook(event, line)
        if self.trace_depth > 0 or #self.trace >= self.max_trace_events then
            return
        end
        self.trace_depth = self.trace_depth + 1
        local info = {}
        if type(debug.getinfo) == "function" then
            local ok, result = pcall(debug.getinfo, 2)
            if ok and type(result) == "table" then
                info = result
            end
        end
        local source = info.short_src or info.source or "?"
        if not tostring(source):find("runtime_dumper", 1, true) then
            local record = string.format(
                "%06d  %-6s  %s:%s  %s",
                #self.trace + 1,
                tostring(event),
                tostring(source),
                tostring(line or info.currentline or "?"),
                tostring(info.name or "anonymous")
            )
            self.trace[#self.trace + 1] = record
            if #self.trace % self.trace_flush_every == 0 then
                -- Keep a live partial trace if the packed VM is long-running
                -- and never reaches Dumper:run's final flush.
                if self.compact then
                    self:_compact_flush_runtime(false)
                else
                    self:_write(self.root .. "/trace.log", table.concat(self.trace, "\n") .. "\n", false)
                    if #self.runtime_values > 0 then
                        self:_write(self.root .. "/values.log", table.concat(self.runtime_values, "\n") .. "\n", false)
                    end
                end
            end
            if (event == "call" or event == "line") and type(debug.getlocal) == "function" then
                for local_index = 1, 40 do
                    local local_ok, local_name, local_value = pcall(debug.getlocal, 2, local_index)
                    if not local_ok or local_name == nil then
                        break
                    end
                    self:_capture_runtime_value(
                        tostring(source) .. ":" .. tostring(line or info.currentline or "?") .. "." .. tostring(local_name),
                        local_value
                    )
                end
            end
        end
        self.trace_depth = self.trace_depth - 1
    end
    local ok = pcall(debug.sethook, hook, "crl", 0)
    if not ok then
        ok = pcall(debug.sethook, hook, "cr")
    end
    self.debug_hook_active = ok
    self:_log(ok and "debug hook installed" or "debug hook rejected")
end

function Dumper:stop()
    if self.debug_hook_active and type(debug) == "table" and type(debug.sethook) == "function" then
        pcall(debug.sethook)
        self.debug_hook_active = false
        self:_log("debug hook stopped")
    end
    self:flush(true)
end

function Dumper:_write_feature_report()
    local features = {
        "writefile", "makefolder", "appendfile", "hookfunction", "newcclosure",
        "getgc", "getreg", "getconnections", "decompile", "getconstants",
        "getupvalues", "getprotos", "getproto", "getgenv",
    }
    local lines = { "runtime-dumper feature detection" }
    for _, name in ipairs(features) do
        lines[#lines + 1] = name .. "=" .. tostring(type((self.env and self.env[name]) or _G[name]) == "function")
    end
    local debug_features = { "getinfo", "getlocal", "getupvalue", "sethook", "traceback" }
    for _, name in ipairs(debug_features) do
        lines[#lines + 1] = "debug." .. name .. "=" .. tostring(type(debug) == "table" and type(debug[name]) == "function")
    end
    lines[#lines + 1] = "string.dump=" .. tostring(type(string.dump) == "function")
    self:_write(self.root .. "/features.txt", table.concat(lines, "\n") .. "\n", false)
end

function Dumper:install()
    if self.installed then
        return self
    end
    self:_ensure_root()
    self:_write_feature_report()
    local readme_lines
    if self.compact then
        readme_lines = {
            "Runtime dumper compact output",
            "=============================",
            "chunks.txt       captured source chunks",
            "http.txt         captured HTTP data",
            "functions.txt    function metadata and closure records",
            "decompiled.txt   bounded source-like decompiles",
            "values.txt       constants, upvalues and runtime values",
            "tables.txt       bounded getgc table snapshots",
            "bytecode.txt     bytecode lengths and hashes",
            "connections.txt  captured connection metadata",
            "trace.txt        bounded call/return/line trace",
            "trace_source.txt source-shaped trace with synthetic names",
            "events.txt       capture events",
            "features.txt     feature-detection report",
            "summary.txt      capture counts",
            "",
            "All compact files are plain text and are split at a bounded size.",
            "Names/upvalues marked synthetic, inferred or unresolved are not",
            "claims about the original obfuscated source.",
        }
    else
        readme_lines = {
            "Runtime dumper output",
            "=====================",
            "chunks/      source strings passed to load/loadstring",
            "http/        captured URLs, request bodies and responses",
            "functions/   debug metadata, decompile output and optional constants",
            "bytecode/    optional string.dump results",
            "snapshots/   errors and bounded getgc table snapshots",
            "values.log   bounded locals/runtime values when exposed",
            "trace.log    bounded call/line trace",
            "trace_source.lua  source-shaped trace listing",
            "features.txt  feature-detection report",
            "events.log   capture events",
            "",
            "The trace is not equivalent to the original source and cannot restore",
            "identifiers that were erased by an obfuscator.",
            "",
        }
    end
    self:_write(self.root .. "/README.txt", table.concat(readme_lines, "\n"), false)
    self:_wrap_global("loadstring")
    self:_wrap_global("load")
    self:_install_http_hooks()
    self:_install_instance_hook()
    self:_install_debug_hook()
    self.installed = true
    self:_log("installed " .. self.VERSION)
    return self
end

function Dumper:run(source, chunk_name, ...)
    self:install()
    if type(source) == "function" then
        self:_capture_function(source, chunk_name or "function")
        local fn_args = { ... }
        local ok, result = xpcall(function()
            return source(unpack_(fn_args))
        end, function(err)
            return tostring(err) .. "\n" .. (debug and debug.traceback and debug.traceback() or "")
        end)
        self:flush()
        if not ok then error(result, 0) end
        return result
    end
    if type(source) ~= "string" then
        error("Dumper:run expects source text or a function", 2)
    end
    self:_capture_loader("run", source, chunk_name or "@runtime_source")
    local loader = self.originals.loadstring or self.originals.load or self.env.loadstring or self.env.load
    if type(loader) ~= "function" then
        error("no loadstring/load function is available", 2)
    end
    local ok, fn_or_error, load_error = pcall(loader, source, chunk_name or "@runtime_source")
    if not ok or type(fn_or_error) ~= "function" then
        local failure = load_error or fn_or_error or "unknown loader failure"
        self:_log("loader failed: " .. tostring(failure))
        self:flush()
        error(failure, 0)
    end
    self:_capture_function(fn_or_error, chunk_name or "runtime_source")
    local args = { ... }
    local ran, result = xpcall(function()
        return fn_or_error(unpack_(args))
    end, function(err)
        local trace = (type(debug) == "table" and type(debug.traceback) == "function") and debug.traceback() or ""
        return tostring(err) .. "\n" .. trace
    end)
    self:flush()
    if not ran then
        local error_path = self.compact and (self.root .. "/error.txt") or (self.root .. "/snapshots/last_error.txt")
        self:_write(error_path, tostring(result) .. "\n", false)
        error(result, 0)
    end
    return result
end

function Dumper:scan_registry(progress)
    if type(getreg) ~= "function" then
        self:_log("getreg unavailable")
        return 0
    end
    local ok, registry = pcall(getreg)
    if not ok or type(registry) ~= "table" then
        self:_log("getreg failed")
        return 0
    end
    local count = 0
    local visited = 0
    for _, object in pairs(registry) do
        visited = visited + 1
        if type(object) == "function" then
            self:_capture_function(object, "getreg")
            count = count + 1
            if count >= self.max_gc_functions then
                break
            end
        end
        if progress and visited % 250 == 0 then
            pcall(progress, visited, count)
            if task and type(task.wait) == "function" then
                pcall(task.wait)
            end
        end
    end
    self:_log("getreg scanned " .. tostring(count) .. " functions")
    self:flush()
    return count
end

function Dumper:scan_connections(signal)
    if type(getconnections) ~= "function" then
        self:_log("getconnections unavailable")
        return 0
    end
    if signal == nil then
        self:_log("getconnections skipped: no signal supplied")
        return 0
    end
    local ok, connections = pcall(getconnections, signal)
    if not ok or type(connections) ~= "table" then
        self:_log("getconnections failed")
        return 0
    end
    local count = 0
    for index, connection in pairs(connections) do
        local callback = nil
        if type(connection) == "table" then
            callback = connection.Function
        else
            local callback_ok, callback_value = pcall(function()
                return connection.Function
            end)
            if callback_ok then
                callback = callback_value
            end
        end
        if type(callback) == "function" then
            self:_capture_function(callback, "connection_" .. tostring(index))
            count = count + 1
        else
            local rendered = string.format(
                "\n--- CONNECTION %s ---\n%s\n",
                tostring(index),
                self:_repr(connection)
            )
            if self.compact then
                self:_compact_append("connections", rendered)
            else
                self:_write(self.root .. "/snapshots/connection_" .. sanitize_name(index) .. ".txt", self:_repr(connection) .. "\n", false)
            end
        end
    end
    self:_log("getconnections captured " .. tostring(count) .. " callbacks")
    self:flush()
    return count
end

function Dumper:scan_gc(progress)
    local scanner = getgc
    if type(scanner) ~= "function" then
        self:_log("getgc unavailable")
        return 0
    end
    local ok, objects = pcall(scanner, true)
    if not ok or type(objects) ~= "table" then
        ok, objects = pcall(scanner)
    end
    if not ok or type(objects) ~= "table" then
        self:_log("getgc failed")
        return 0
    end
    local count = 0
    local tables = 0
    local visited = 0
    for _, object in pairs(objects) do
        visited = visited + 1
        if type(object) == "function" then
            self:_capture_function(object, "getgc")
            count = count + 1
        elseif type(object) == "table" and tables < self.max_gc_tables then
            tables = tables + 1
            self.table_count = self.table_count + 1
            local rendered = string.format(
                "\n--- TABLE %05d ---\n%s\n",
                self.table_count,
                self:_repr(object)
            )
            if self.compact then
                self:_compact_append("tables", rendered)
            else
                local snapshot = "getgc_table_" .. string.format("%05d", self.table_count)
                self:_write(self.root .. "/snapshots/" .. snapshot .. ".txt", self:_repr(object) .. "\n", false)
            end
        end
        if progress and visited % 250 == 0 then
            pcall(progress, visited, count, tables)
            if task and type(task.wait) == "function" then
                pcall(task.wait)
            end
        end
        if count >= self.max_gc_functions and tables >= self.max_gc_tables then
            break
        end
    end
    if progress then
        pcall(progress, visited, count, tables)
    end
    self:_log("getgc scanned " .. tostring(count) .. " functions and " .. tostring(tables) .. " tables")
    self:flush()
    return count
end

function Dumper:flush(final)
    if self.compact then
        self:_compact_flush_runtime(final == true)
    else
        if #self.events > 0 then
            self:_write(self.root .. "/events.log", table.concat(self.events, "\n") .. "\n", true)
            self.events = {}
        end
        if #self.runtime_values > 0 then
            self:_write(self.root .. "/values.log", table.concat(self.runtime_values, "\n") .. "\n", false)
        end
        if #self.trace > 0 then
            self:_write(self.root .. "/trace.log", table.concat(self.trace, "\n") .. "\n", false)
            local listing = {
                "-- Runtime trace listing; this is a source-shaped view, not recovered source.",
                "-- Synthetic identifiers and the upvalue note below are explicit.",
                "-- Generated by runtime_dumper.lua",
                "",
                "local function runtime_trace_0000(...)",
                "    -- upvalues: INFERRED/UNRESOLVED (debug hook does not expose original locals)",
            }
            for index, line in ipairs(self.trace) do
                listing[#listing + 1] = string.format("    -- line %06d | %s", index, line)
            end
            listing[#listing + 1] = "end"
            self:_write(self.root .. "/trace_source.lua", table.concat(listing, "\n") .. "\n", false)
        end
    end
    local summary = {
        "version=" .. self.VERSION,
        "compact=" .. tostring(self.compact),
        "trace_events=" .. tostring(#self.trace),
        "unique_functions=" .. tostring(self.function_count),
        "decompiled_functions=" .. tostring(self.decompiled_count),
        "table_snapshots=" .. tostring(self.table_count),
        "runtime_values=" .. tostring(#self.runtime_values),
        "unique_text_captures=" .. tostring(self.text_count),
        "installed=" .. tostring(self.installed),
        "elapsed=" .. tostring(os.clock() - self.started_at),
    }
    self:_write(self.root .. "/summary.txt", table.concat(summary, "\n") .. "\n", false)
end

return Dumper.new()
